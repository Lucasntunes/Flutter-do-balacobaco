class FormatacaoNuvem {
  String

}