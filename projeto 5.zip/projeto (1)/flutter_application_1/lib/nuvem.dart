import 'package:flutter/material.dart';
import 'dart:math';

class Nuvem extends StatefulWidget {
  const Nuvem({super.key});

  @override
  State<Nuvem> createState() => _NuvemState();
}

class _NuvemState extends State<Nuvem> {
  List<String> lista = ["tabela 1", "tabela 2", "tabela 3","tabela 1", "tabela 2", "tabela 3""tabela 1", "tabela 2", "tabela 3"];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Tabelas salvas na nuvem"),
        centerTitle: true,
      ),
      body: 
      Padding(
        padding: const EdgeInsets.all(20.0),
        child: GridView.count(
          crossAxisCount: (MediaQuery.of(context).size.width/200).toInt(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          children: List.generate(
            lista.length,
            (index) => Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.teal[100 * (index + 1)],
                borderRadius: BorderRadius.circular(10),
              ),
              child: Center(
                child: Text(
                  lista[index],
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}