import 'package:flutter/material.dart';



class Nuvem extends StatefulWidget {
  const Nuvem({super.key});

List<String> lista = ["tabela 1","tabela 2","tabela 3"];

  @override
  State<Nuvem> createState() => _NuvemState();
}

class _NuvemState extends State<Nuvem> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Tabelas salvas na nuvem"),centerTitle: true,),
    body: Center(child: Column(
      
      
      children: [
    

    ],),),
    );
  }
}