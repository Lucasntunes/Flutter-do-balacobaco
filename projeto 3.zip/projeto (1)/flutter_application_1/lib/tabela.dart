import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Antibióticos',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const AntibioticScreen(),
    );
  }
}

class AntibioticScreen extends StatefulWidget {
  const AntibioticScreen({super.key});

  @override
  _AntibioticScreenState createState() => _AntibioticScreenState();
}

class _AntibioticScreenState extends State<AntibioticScreen> {
  final List<Antibiotic> antibiotics = [
    Antibiotic(
      id: 1,
      name: "AZITROMICINA",
      type: "Macrolídeos",
      gramPositive: true,
      gramNegative: true,
      morphology: "Bacilos",
    ),
    Antibiotic(
      id: 2,
      name: "CLARITROMICINA",
      type: "Macrolídeos",
      gramPositive: true,
      gramNegative: true,
      morphology: "Bacilos",
    ),
    Antibiotic(id: 3,
     name: Oxacilinas, 
     type: Penicilinas, 
     gramPositive: true,
      gramNegative: true, 
      morphology: Bacilos),
    Antibiotic(id: 4, name: Ampicilina, type: Penicilinas, 
    gramPositive: true, gramNegative: true, morphology: Cocos e Bacilos),
    Antibiotic(id: 5, name: Amoxicilina, type: Penicilina, gramPositive: true,
     gramNegative: true, morphology: Cocos e Bacilo),
       Antibiotic(id: 6, name: Ampicilina+Sulbactam, type: Penicilina, gramPositive: true,
     gramNegative: true, morphology: Cocos e Bacilo),
         Antibiotic(id: 7, name: Amoxicilina+Clavulanato, type: Penicilina, gramPositive: true,
     gramNegative: true, morphology: Cocos e Bacilo),
         Antibiotic(id: 7, name: Penicilina G Benzatina, type: Penicilina, gramPositive: true,
     gramNegative: true, morphology: Cocos e Bacilo),
         Antibiotic(id: 7, name: Amoxicilina+Clavulanato, type: Penicilina, gramPositive: true,
     gramNegative: true, morphology: Cocos e Bacilo),
         Antibiotic(id: 7, name: Amoxicilina+Clavulanato, type: Penicilina, gramPositive: true,
     gramNegative: true, morphology: Cocos e Bacilo),
         Antibiotic(id: 7, name: Amoxicilina+Clavulanato, type: Penicilina, gramPositive: true,
     gramNegative: true, morphology: Cocos e Bacilo),
         Antibiotic(id: 7, name: Amoxicilina+Clavulanato, type: Penicilina, gramPositive: true,
     gramNegative: true, morphology: Cocos e Bacilo),
  
  ];

  final List<String> antibioticTypes = [
    "Macrolídeos",
    "Penicilinas",
    "Cefalosporinas",
    "Carbapenêmicos",
    "Aminoglicosídeos",
    "Quinolonas",
    "Anfenicóis",
    "Sulfonamidas",
    "Glicopeptídeos",
    "Nitroimidazólicos",
    "Licosamidas",
    "Polimixinas",
    "Oxazolidinona",
    "Glicilciclina",
    "Antituberculosos"
  ];

  final List<String> morphologyOptions = [
    "Cocos",
    "Bacilos",
    "Cocos e Bacilos"
  ];

  // Filtros
  String nameFilter = '';
  String? typeFilter;
  bool? gramPositiveFilter;
  bool? gramNegativeFilter;
  String? morphologyFilter;

  List<Antibiotic> get filteredAntibiotics => antibiotics.where((antibiotic) {
        return antibiotic.name.toLowerCase().contains(nameFilter.toLowerCase()) &&
            (typeFilter == null || antibiotic.type == typeFilter) &&
            (gramPositiveFilter == null || antibiotic.gramPositive == gramPositiveFilter) &&
            (gramNegativeFilter == null || antibiotic.gramNegative == gramNegativeFilter) &&
            (morphologyFilter == null || antibiotic.morphology == morphologyFilter);
      }).toList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lista de Antibióticos')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildFilters(),
            const SizedBox(height: 20),
            Expanded(
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  columns: const [
                    DataColumn(label: Text('Nome do Antibiótico')),
                    DataColumn(label: Text('Tipo de Antibiótico')),
                    DataColumn(label: Text('Age em Gram+')),
                    DataColumn(label: Text('Age em Gram-')),
                    DataColumn(label: Text('Morfologia Bacteriana')),
                  ],
                  rows: filteredAntibiotics.map((antibiotic) {
                    return DataRow(cells: [
                      DataCell(Text(antibiotic.name)),
                      DataCell(Text(antibiotic.type)),
                      DataCell(Text(antibiotic.gramPositive ? 'Sim' : 'Não')),
                      DataCell(Text(antibiotic.gramNegative ? 'Sim' : 'Não')),
                      DataCell(Text(antibiotic.morphology)),
                    ]);
                  }).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilters() {
    return Column(
      children: [
        TextField(
          decoration: const InputDecoration(
            labelText: 'Filtrar por Nome',
            suffixIcon: Icon(Icons.search),
          ),
          onChanged: (value) => setState(() => nameFilter = value),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: DropdownButtonFormField<String>(
                value: typeFilter,
                items: [
                  const DropdownMenuItem(
                    value: null,
                    child: Text('Todos os Tipos'),
                  ),
                  ...antibioticTypes.map((type) {
                    return DropdownMenuItem(
                      value: type,
                      child: Text(type),
                    );
                  }),
                ],
                onChanged: (value) => setState(() => typeFilter = value),
                decoration: const InputDecoration(labelText: 'Filtrar por Tipo'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: DropdownButtonFormField<String>(
                value: morphologyFilter,
                items: [
                  const DropdownMenuItem(
                    value: null,
                    child: Text('Todas Morfologias'),
                  ),
                  ...morphologyOptions.map((morphology) {
                    return DropdownMenuItem(
                      value: morphology,
                      child: Text(morphology),
                    );
                  }),
                ],
                onChanged: (value) => setState(() => morphologyFilter = value),
                decoration: const InputDecoration(labelText: 'Filtrar por Morfologia'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: DropdownButtonFormField<bool>(
                value: gramPositiveFilter,
                items: [
                  const DropdownMenuItem(
                    value: null,
                    child: Text('Gram+ (Todos)'),
                  ),
                  const DropdownMenuItem(
                    value: true,
                    child: Text('Gram+ (Sim)'),
                  ),
                  const DropdownMenuItem(
                    value: false,
                    child: Text('Gram+ (Não)'),
                  ),
                ],
                onChanged: (value) => setState(() => gramPositiveFilter = value),
                decoration: const InputDecoration(labelText: 'Filtrar Gram+'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: DropdownButtonFormField<bool>(
                value: gramNegativeFilter,
                items: [
                  const DropdownMenuItem(
                    value: null,
                    child: Text('Gram- (Todos)'),
                  ),
                  const DropdownMenuItem(
                    value: true,
                    child: Text('Gram- (Sim)'),
                  ),
                  const DropdownMenuItem(
                    value: false,
                    child: Text('Gram- (Não)'),
                  ),
                ],
                onChanged: (value) => setState(() => gramNegativeFilter = value),
                decoration: const InputDecoration(labelText: 'Filtrar Gram-'),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class Antibiotic {
  final int id;
  final String name;
  final String type;
  final bool gramPositive;
  final bool gramNegative;
  final String morphology;

  Antibiotic({
    required this.id,
    required this.name,
    required this.type,
    required this.gramPositive,
    required this.gramNegative,
    required this.morphology,
  });
}